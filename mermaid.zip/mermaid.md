## Option 1
```mermaid
erDiagram

    Library {
        INTEGER library_id PK
        VARCHAR facility_ids "'facility1_id','facility1_2d',...."
        VARCHAR library_nearby_ids
        VARCHAR service_ids
        VARCHAR library_name
        VARCHAR short_address "for the location link"
        VARCHAR eric_code
        VARCHAR address_line1
        VARCHAR address_line2
        VARCHAR address_line3
        VARCHAR pic_url "link to file system"
        VARCHAR memo
        VARCHAR phone
        VARCHAR email
        INTEGER status "0: available, 1: unavailable"
    }

    Library ||--o{ Facility : has
    Facility {
        INTEGER facility_id PK
        VARCHAR facility_name
        INTEGER status "0: available, 1: unavailable"
        VARCHAR memo
    }

    %%Library ||--o{ Share : has
    Share {
        INTEGER website_id PK
        INTEGER status "0: available, 1: unavailable"
        VARCHAR website_logo_url
        VARCHAR website_name
        VARCHAR share_link
        
    }
    
    %% data rows is fixed, libraries num * 7 days, just can change opening time
    %% Today is which day can get from system date or from Internet
    Library ||--o{ OpeningHour : has
    OpeningHour {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER day  "1: sunday, 2: monday, 3 ..."
        VARCHAR open_time "10:00 – 20:00"
    }

    Library ||--o{ Service : has
    Service {
        INTEGER service_id PK
        INTEGER status "0: available, 1: unavailable"
        VARCHAR service_name
        VARCHAR memo
    }

    Library ||--|| Story : has
    Story {
        INTEGER story_id PK
        INTEGER library_id PK
        VARCHAR title
        VARCHAR description
        VARCHAR video_url
        VARCHAR pic_url
        VARCHAR doc_url "word pdf ..."
    }

    Library ||--o{ Event : has
    Event {
        INTEGER event_id PK
        VARCHAR title1
        VARCHAR title2
        DATETIME event_time
        VARCHAR info
        INTEGER text_id FK
        
    }

    Event ||--|| EventText : has
    EventText {
        INTEGER id PK
        INTEGER event_id FK
        TEXT text
    }
    
    


```
## Option 2
```mermaid
 
erDiagram

    Library {
        INTEGER library_id PK
        VARCHAR library_name
        VARCHAR short_address "for the location link"
        VARCHAR eric_code
        VARCHAR address_line1
        VARCHAR address_line2
        VARCHAR address_line3
        VARCHAR pic_url "link to file system"
        VARCHAR memo
        VARCHAR phone
        VARCHAR email
    }

    Library ||--o{ LibraryNearby : has
    LibraryNearby {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER nearby_id FK
    }

    
    Facility {
        INTEGER facility_id PK
        VARCHAR facility_name
        VARCHAR memo
    }

    Library ||--o{ LibraryFacility : has
    Facility ||--o{ LibraryFacility : has
    LibraryFacility {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER facility_id FK
    }

    Service {
        INTEGER service_id PK
        INTEGER status "0: available, 1: unavailable"
        VARCHAR service_name
        VARCHAR memo
    }

    Library ||--o{ LibraryService : has
    Service ||--o{ LibraryService : has
    LibraryService {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER service_id FK
    }

    Event {
        INTEGER event_id PK
        INTEGER text_id FK
        DATETIME event_time
        VARCHAR title1
        VARCHAR title2
        VARCHAR info
        
    }

    Library ||--o{ LibraryEvent : has
    Event ||--o{ LibraryEvent : has
    LibraryEvent {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER event_id FK
    }    

    Event ||--|| EventText : has
    EventText {
        INTEGER id PK
        INTEGER event_id FK
        TEXT text
    }

    Library ||--|| Story : has
    Story {
        INTEGER story_id PK
        INTEGER library_id PK
        VARCHAR title
        VARCHAR description
        VARCHAR video_url
        VARCHAR pic_url
        VARCHAR doc_url "word pdf ..."
    }
    
    %% Login: userId
    %% no login: userIp
    %% order by PK desc
    SearchHistory {
        INTEGER search_id PK
        INTEGER user_id
        VARCHAR user_ip
        VARCHAR search_info
        DATETIME search_time
    }

    Library ||--o{ OpeningHour : has
    OpeningHour {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER day  "1: sunday, 2: monday, 3 ..."
        VARCHAR open_time "10:00 – 20:00"
    }
    
```


## Option 3
```mermaid

erDiagram

    Library {
        INTEGER library_id PK
        VARCHAR facility_ids
        VARCHAR library_nearby_ids
        VARCHAR library_name
        VARCHAR short_address "for the location link"
        VARCHAR eric_code
        VARCHAR address_line1
        VARCHAR address_line2
        VARCHAR address_line3
        INTEGER file_id FK
        VARCHAR memo
    }


    Facility {
        INTEGER facility_id PK
        VARCHAR facility_name
        VARCHAR memo
    }

    Service {
        INTEGER service_id PK
        INTEGER status "0: available, 1: unavailable"
        VARCHAR service_name
        VARCHAR memo
    }

    Library ||--o{ Bridge : has
    Facility ||--o{ Bridge : has
    Service ||--o{ Bridge : has
    Bridge {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER type "0:nearby, 1:facility, 2: service ...."
        INTEGER related_id FK
        VARCHAR related_name
    }

    Library ||--|| Story : has
    Story {
        INTEGER story_id PK
        INTEGER library_id PK
        VARCHAR title
        VARCHAR description
        VARCHAR video_url
        VARCHAR pic_url
        VARCHAR doc_url "word pdf ..."
    }

    Library ||--o{ Event : has
    Event {
        INTEGER event_id PK
        VARCHAR title1
        VARCHAR title2
        DATETIME event_time
        VARCHAR info
        INTEGER text_id "file_id"
    }

    Event ||--|| EventText : has
    EventText {
        INTEGER id PK
        INTEGER event_id FK
        TEXT text
    }
    

    Library ||--o{ OpeningHour : has
    OpeningHour {
        INTEGER id PK
        INTEGER library_id FK
        INTEGER day  "1: sunday, 2: monday, 3 ..."
        VARCHAR open_time "10:00 – 20:00"
    }

```